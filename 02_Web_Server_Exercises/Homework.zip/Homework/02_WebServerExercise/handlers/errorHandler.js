module.exports = (request, response) => {
  response.writeHTML('./views/error.html')
}
