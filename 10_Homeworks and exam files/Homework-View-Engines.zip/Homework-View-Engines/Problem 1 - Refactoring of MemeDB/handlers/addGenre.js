module.exports = (req, res) => {
  res.render('addGenre')
}
