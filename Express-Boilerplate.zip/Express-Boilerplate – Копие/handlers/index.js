const homeHandler = require('./home')
const aboutHandler = require('./about')

module.exports = {
  home: homeHandler,
  about: aboutHandler

}
