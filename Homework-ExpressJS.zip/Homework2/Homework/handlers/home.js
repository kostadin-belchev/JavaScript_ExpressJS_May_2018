module.exports = (req, res) => {
  res.render('home')
}
